from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import requests
from bs4 import BeautifulSoup
import os
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# Initialize API
app = FastAPI(title="LeadSnatch API", version="1.2")

# Serve index.html as homepage
@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    with open("index.html", "r") as f:
        return f.read()

# Input models
class ScrapeRequest(BaseModel):
    url: str

class GenerateRequest(BaseModel):
    competitor_summary: str
    mention_competitor: bool = False

class AutopilotRequest(BaseModel):
    url: str
    mention_competitor: bool = False

# Scraping endpoint
@app.post("/scrape")
async def scrape_website(data: ScrapeRequest):
    try:
        response = requests.get(data.url, timeout=10)
        response.raise_for_status()
    except Exception as e:
        return {"error": str(e)}

    soup = BeautifulSoup(response.text, "html.parser")
    meta_description = soup.find("meta", attrs={"name": "description"})
    headings = [h.get_text(strip=True) for h in soup.find_all(["h1", "h2"])]

    competitor_summary = f"Meta Description: {meta_description['content'] if meta_description else 'None'}\n"
    competitor_summary += "Headings: " + ", ".join(headings[:5])

    return {
        "url": data.url,
        "meta_description": meta_description["content"] if meta_description else None,
        "headings": headings[:5],
        "competitor_summary": competitor_summary
    }

# Generation endpoint
@app.post("/generate")
async def generate_counterpitch(data: GenerateRequest):
    try:
        if data.mention_competitor:
            prompt = (
                f"You are a sales strategist. Based on this competitor's positioning below:\n\n"
                f"{data.competitor_summary}\n\n"
                f"Write a persuasive cold email introducing an alternative solution. "
                f"Reference the competitor as a common tool (e.g. 'While many teams rely on X...'), "
                f"but do not assume the reader uses it. Focus on why your offer is smarter, more efficient, or more valuable. "
                f"Flip the competitor’s strengths into weaknesses if possible. "
                f"Keep the tone direct, confident, and benefit-driven."
            )
        else:
            prompt = (
                f"You are a sales strategist. Based on this competitor's positioning below:\n\n"
                f"{data.competitor_summary}\n\n"
                f"Write a persuasive cold email introducing an alternative solution "
                f"without mentioning or referencing the competitor. "
                f"Focus entirely on why your solution is smarter, more efficient, or more valuable. "
                f"Keep the tone direct, confident, and benefit-driven."
            )

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )

        reply = response.choices[0].message.content.strip()

        return {"counterpitch_email": reply}

    except Exception as e:
        return {"error": str(e)}

# Autopilot endpoint
@app.post("/autopilot")
async def autopilot_counterpitch(data: AutopilotRequest):
    try:
        response = requests.get(data.url, timeout=10)
        response.raise_for_status()
    except Exception as e:
        return {"error": f"Scraping failed: {str(e)}"}

    soup = BeautifulSoup(response.text, "html.parser")
    meta_description = soup.find("meta", attrs={"name": "description"})
    headings = [h.get_text(strip=True) for h in soup.find_all(["h1", "h2"])]

    competitor_summary = f"Meta Description: {meta_description['content'] if meta_description else 'None'}\n"
    competitor_summary += "Headings: " + ", ".join(headings[:5])

    if data.mention_competitor:
        prompt = (
            f"You are a sales strategist. Based on this competitor's positioning below:\n\n"
            f"{competitor_summary}\n\n"
            f"Write a persuasive cold email introducing an alternative solution. "
            f"Reference the competitor as a common tool (e.g. 'While many teams rely on X...'), "
            f"but do not assume the reader uses it. Focus on why your offer is smarter, more efficient, or more valuable. "
            f"Flip the competitor’s strengths into weaknesses if possible. "
            f"Keep the tone direct, confident, and benefit-driven."
        )
    else:
        prompt = (
            f"You are a sales strategist. Based on this competitor's positioning below:\n\n"
            f"{competitor_summary}\n\n"
            f"Write a persuasive cold email introducing an alternative solution "
            f"without mentioning or referencing the competitor. "
            f"Focus entirely on why your solution is smarter, more efficient, or more valuable. "
            f"Keep the tone direct, confident, and benefit-driven."
        )

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )

        reply = response.choices[0].message.content.strip()

        return {
            "url_scraped": data.url,
            "competitor_summary": competitor_summary,
            "counterpitch_email": reply
        }

    except Exception as e:
        return {"error": f"OpenAI generation failed: {str(e)}"}